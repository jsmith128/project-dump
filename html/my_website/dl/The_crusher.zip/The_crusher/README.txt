Just place the bsp file into your 
C:\Program Files (x86)\Steam\steamapps\common\Half-Life 2\hl2\maps folder, then type "map the_crusher_final" in your console without the quotation marks.